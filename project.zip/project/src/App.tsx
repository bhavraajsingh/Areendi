import React from 'react';
import MeetingTemplate from './components/MeetingTemplate';

function App() {
  return <MeetingTemplate />;
}

export default App;