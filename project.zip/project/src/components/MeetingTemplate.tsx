import React, { useState, useEffect } from 'react';
import { Calendar, User, Clock, Plus, Trash2, Save, Download, FileText, Sparkles, FileDown } from 'lucide-react';

interface CompletedTask {
  id: string;
  name: string;
  notes: string;
}

interface InProgressTask {
  id: string;
  task: string;
  dueDate: string;
  notes: string;
}

interface UpcomingTask {
  id: string;
  task: string;
  dueDate: string;
  notes: string;
}

interface Challenge {
  id: string;
  challenge: string;
  suggestedSolution: string;
}

interface ActionItem {
  id: string;
  item: string;
  owner: string;
  dueDate: string;
  status: string;
}

interface MeetingData {
  date: string;
  duration: string;
  completedTasks: CompletedTask[];
  inProgressTasks: InProgressTask[];
  upcomingTasks: UpcomingTask[];
  challenges: Challenge[];
  actionItems: ActionItem[];
}

const MeetingTemplate: React.FC = () => {
  const [meetingData, setMeetingData] = useState<MeetingData>({
    date: '',
    duration: '30 mins',
    completedTasks: [],
    inProgressTasks: [],
    upcomingTasks: [],
    challenges: [],
    actionItems: []
  });

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedData = localStorage.getItem('meeting-template-data');
    if (savedData) {
      setMeetingData(JSON.parse(savedData));
    }
  }, []);

  // Save data to localStorage whenever meetingData changes
  useEffect(() => {
    localStorage.setItem('meeting-template-data', JSON.stringify(meetingData));
  }, [meetingData]);

  const updateField = (field: keyof MeetingData, value: string) => {
    setMeetingData(prev => ({ ...prev, [field]: value }));
  };

  const addCompletedTask = () => {
    const newTask: CompletedTask = {
      id: Date.now().toString(),
      name: '',
      notes: ''
    };
    setMeetingData(prev => ({
      ...prev,
      completedTasks: [...prev.completedTasks, newTask]
    }));
  };

  const updateCompletedTask = (id: string, field: keyof CompletedTask, value: string) => {
    setMeetingData(prev => ({
      ...prev,
      completedTasks: prev.completedTasks.map(task =>
        task.id === id ? { ...task, [field]: value } : task
      )
    }));
  };

  const removeCompletedTask = (id: string) => {
    setMeetingData(prev => ({
      ...prev,
      completedTasks: prev.completedTasks.filter(task => task.id !== id)
    }));
  };

  const addInProgressTask = () => {
    const newTask: InProgressTask = {
      id: Date.now().toString(),
      task: '',
      dueDate: '',
      notes: ''
    };
    setMeetingData(prev => ({
      ...prev,
      inProgressTasks: [...prev.inProgressTasks, newTask]
    }));
  };

  const updateInProgressTask = (id: string, field: keyof InProgressTask, value: string) => {
    setMeetingData(prev => ({
      ...prev,
      inProgressTasks: prev.inProgressTasks.map(task =>
        task.id === id ? { ...task, [field]: value } : task
      )
    }));
  };

  const removeInProgressTask = (id: string) => {
    setMeetingData(prev => ({
      ...prev,
      inProgressTasks: prev.inProgressTasks.filter(task => task.id !== id)
    }));
  };

  const addUpcomingTask = () => {
    const newTask: UpcomingTask = {
      id: Date.now().toString(),
      task: '',
      dueDate: '',
      notes: ''
    };
    setMeetingData(prev => ({
      ...prev,
      upcomingTasks: [...prev.upcomingTasks, newTask]
    }));
  };

  const updateUpcomingTask = (id: string, field: keyof UpcomingTask, value: string) => {
    setMeetingData(prev => ({
      ...prev,
      upcomingTasks: prev.upcomingTasks.map(task =>
        task.id === id ? { ...task, [field]: value } : task
      )
    }));
  };

  const removeUpcomingTask = (id: string) => {
    setMeetingData(prev => ({
      ...prev,
      upcomingTasks: prev.upcomingTasks.filter(task => task.id !== id)
    }));
  };

  const addChallenge = () => {
    const newChallenge: Challenge = {
      id: Date.now().toString(),
      challenge: '',
      suggestedSolution: ''
    };
    setMeetingData(prev => ({
      ...prev,
      challenges: [...prev.challenges, newChallenge]
    }));
  };

  const updateChallenge = (id: string, field: keyof Challenge, value: string) => {
    setMeetingData(prev => ({
      ...prev,
      challenges: prev.challenges.map(challenge =>
        challenge.id === id ? { ...challenge, [field]: value } : challenge
      )
    }));
  };

  const removeChallenge = (id: string) => {
    setMeetingData(prev => ({
      ...prev,
      challenges: prev.challenges.filter(challenge => challenge.id !== id)
    }));
  };

  const addActionItem = () => {
    const newItem: ActionItem = {
      id: Date.now().toString(),
      item: '',
      owner: '',
      dueDate: '',
      status: 'Not Started'
    };
    setMeetingData(prev => ({
      ...prev,
      actionItems: [...prev.actionItems, newItem]
    }));
  };

  const updateActionItem = (id: string, field: keyof ActionItem, value: string) => {
    setMeetingData(prev => ({
      ...prev,
      actionItems: prev.actionItems.map(item =>
        item.id === id ? { ...item, [field]: value } : item
      )
    }));
  };

  const removeActionItem = (id: string) => {
    setMeetingData(prev => ({
      ...prev,
      actionItems: prev.actionItems.filter(item => item.id !== id)
    }));
  };

  const exportToMarkdown = () => {
    const markdown = `# Weekly 1:1 Meeting Template

---

## Section 1: Meeting Details

* Date of Meeting: ${meetingData.date}
* Meeting Duration: ${meetingData.duration}

---

## Section 2: Completed Tasks

| Task Name | Notes / Context |
| --------- | --------------- |
${meetingData.completedTasks.map(task => `| ${task.name} | ${task.notes} |`).join('\n')}

---

## Section 3: In Progress & Upcoming Work

### Tasks in Progress

| Task in Progress | Due Date | Notes |
| ---------------- | -------- | ----- |
${meetingData.inProgressTasks.map(task => `| ${task.task} | ${task.dueDate} | ${task.notes} |`).join('\n')}

### Upcoming Tasks

| Upcoming Task | Due Date | Notes |
| ------------- | -------- | ----- |
${meetingData.upcomingTasks.map(task => `| ${task.task} | ${task.dueDate} | ${task.notes} |`).join('\n')}

---

## Section 4: Roadblocks or Challenges

| Challenges | Suggested Solutions |
| ---------- | ------------------- |
${meetingData.challenges.map(challenge => `| ${challenge.challenge} | ${challenge.suggestedSolution} |`).join('\n')}

---

## Section 5: Action Items & Follow-Ups

| Action Item | Owner | Due Date | Status |
| ----------- | ----- | -------- | ------ |
${meetingData.actionItems.map(item => `| ${item.item} | ${item.owner} | ${item.dueDate} | ${item.status} |`).join('\n')}

---

📌 Tip: Duplicate this template weekly to create a running log of your 1:1s and progress.`;

    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `1on1-meeting-${meetingData.date || 'template'}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportToPDF = () => {
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Weekly 1:1 Meeting Template - ${meetingData.date || 'Template'}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
            h2 { color: #666; margin-top: 30px; }
            h3 { color: #888; margin-top: 20px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f5f5f5; font-weight: bold; }
            .section { margin-bottom: 30px; }
            @media print { body { margin: 0; } }
          </style>
        </head>
        <body>
          <h1>Weekly 1:1 Meeting Template</h1>
          
          <div class="section">
            <h2>Section 1: Meeting Details</h2>
            <p><strong>Date of Meeting:</strong> ${meetingData.date}</p>
            <p><strong>Meeting Duration:</strong> ${meetingData.duration}</p>
          </div>

          <div class="section">
            <h2>Section 2: Completed Tasks</h2>
            <table>
              <thead>
                <tr>
                  <th>Task Name</th>
                  <th>Notes / Context</th>
                </tr>
              </thead>
              <tbody>
                ${meetingData.completedTasks.map(task => `
                  <tr>
                    <td>${task.name}</td>
                    <td>${task.notes}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="section">
            <h2>Section 3: In Progress & Upcoming Work</h2>
            <h3>Tasks in Progress</h3>
            <table>
              <thead>
                <tr>
                  <th>Task in Progress</th>
                  <th>Due Date</th>
                  <th>Notes</th>
                </tr>
              </thead>
              <tbody>
                ${meetingData.inProgressTasks.map(task => `
                  <tr>
                    <td>${task.task}</td>
                    <td>${task.dueDate}</td>
                    <td>${task.notes}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            
            <h3>Upcoming Tasks</h3>
            <table>
              <thead>
                <tr>
                  <th>Upcoming Task</th>
                  <th>Due Date</th>
                  <th>Notes</th>
                </tr>
              </thead>
              <tbody>
                ${meetingData.upcomingTasks.map(task => `
                  <tr>
                    <td>${task.task}</td>
                    <td>${task.dueDate}</td>
                    <td>${task.notes}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="section">
            <h2>Section 4: Roadblocks or Challenges</h2>
            <table>
              <thead>
                <tr>
                  <th>Challenges</th>
                  <th>Suggested Solutions</th>
                </tr>
              </thead>
              <tbody>
                ${meetingData.challenges.map(challenge => `
                  <tr>
                    <td>${challenge.challenge}</td>
                    <td>${challenge.suggestedSolution}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="section">
            <h2>Section 5: Action Items & Follow-Ups</h2>
            <table>
              <thead>
                <tr>
                  <th>Action Item</th>
                  <th>Owner</th>
                  <th>Due Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${meetingData.actionItems.map(item => `
                  <tr>
                    <td>${item.item}</td>
                    <td>${item.owner}</td>
                    <td>${item.dueDate}</td>
                    <td>${item.status}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const clearForm = () => {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      setMeetingData({
        date: '',
        duration: '30 mins',
        completedTasks: [],
        inProgressTasks: [],
        upcomingTasks: [],
        challenges: [],
        actionItems: []
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl shadow-lg border border-purple-200 p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-yellow-300" />
                Weekly 1:1 Meeting Template
              </h1>
            </div>
          </div>
        </div>

        {/* Section 1: Meeting Details */}
        <div className="bg-white rounded-xl shadow-lg border border-blue-200 p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-500" />
            Section 1: Meeting Details
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date of Meeting</label>
              <input
                type="date"
                value={meetingData.date}
                onChange={(e) => updateField('date', e.target.value)}
                className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Meeting Duration</label>
              <select
                value={meetingData.duration}
                onChange={(e) => updateField('duration', e.target.value)}
                className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="15 mins">15 mins</option>
                <option value="30 mins">30 mins</option>
                <option value="45 mins">45 mins</option>
                <option value="60 mins">60 mins</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Completed Tasks */}
        <div className="bg-white rounded-xl shadow-lg border border-green-200 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Section 2: Completed Tasks</h2>
            <button
              onClick={addCompletedTask}
              className="flex items-center gap-2 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Task
            </button>
          </div>
          <p className="text-gray-600 mb-4">Log completed work, including relevant context.</p>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-green-200">
              <thead>
                <tr className="bg-green-50">
                  <th className="border border-green-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Task Name</th>
                  <th className="border border-green-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Notes / Context</th>
                  <th className="border border-green-200 px-3 py-2 text-center text-sm font-medium text-gray-700 w-12">Actions</th>
                </tr>
              </thead>
              <tbody>
                {meetingData.completedTasks.map((task) => (
                  <tr key={task.id}>
                    <td className="border border-green-200 px-3 py-2">
                      <input
                        type="text"
                        value={task.name}
                        onChange={(e) => updateCompletedTask(task.id, 'name', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-green-500 rounded"
                        placeholder="Task name"
                      />
                    </td>
                    <td className="border border-green-200 px-3 py-2">
                      <input
                        type="text"
                        value={task.notes}
                        onChange={(e) => updateCompletedTask(task.id, 'notes', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-green-500 rounded"
                        placeholder="Notes or context"
                      />
                    </td>
                    <td className="border border-green-200 px-3 py-2 text-center">
                      <button
                        onClick={() => removeCompletedTask(task.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {meetingData.completedTasks.length === 0 && (
                  <tr>
                    <td colSpan={3} className="border border-green-200 px-3 py-4 text-center text-gray-500">
                      No completed tasks yet. Click "Add Task" to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 3: In Progress & Upcoming Work */}
        <div className="bg-white rounded-xl shadow-lg border border-orange-200 p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Section 3: In Progress & Upcoming Work</h2>
          
          {/* Tasks in Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-800">Tasks in Progress</h3>
              <button
                onClick={addInProgressTask}
                className="flex items-center gap-2 px-3 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Task
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-orange-200">
                <thead>
                  <tr className="bg-orange-50">
                    <th className="border border-orange-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Task in Progress</th>
                    <th className="border border-orange-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Due Date</th>
                    <th className="border border-orange-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Notes</th>
                    <th className="border border-orange-200 px-3 py-2 text-center text-sm font-medium text-gray-700 w-12">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {meetingData.inProgressTasks.map((task) => (
                    <tr key={task.id}>
                      <td className="border border-orange-200 px-3 py-2">
                        <input
                          type="text"
                          value={task.task}
                          onChange={(e) => updateInProgressTask(task.id, 'task', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-orange-500 rounded"
                          placeholder="Task description"
                        />
                      </td>
                      <td className="border border-orange-200 px-3 py-2">
                        <input
                          type="date"
                          value={task.dueDate}
                          onChange={(e) => updateInProgressTask(task.id, 'dueDate', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-orange-500 rounded"
                        />
                      </td>
                      <td className="border border-orange-200 px-3 py-2">
                        <input
                          type="text"
                          value={task.notes}
                          onChange={(e) => updateInProgressTask(task.id, 'notes', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-orange-500 rounded"
                          placeholder="Notes"
                        />
                      </td>
                      <td className="border border-orange-200 px-3 py-2 text-center">
                        <button
                          onClick={() => removeInProgressTask(task.id)}
                          className="text-red-500 hover:text-red-700 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {meetingData.inProgressTasks.length === 0 && (
                    <tr>
                      <td colSpan={4} className="border border-orange-200 px-3 py-4 text-center text-gray-500">
                        No tasks in progress yet. Click "Add Task" to get started.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Upcoming Tasks */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-800">Upcoming Tasks</h3>
              <button
                onClick={addUpcomingTask}
                className="flex items-center gap-2 px-3 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Task
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-yellow-200">
                <thead>
                  <tr className="bg-yellow-50">
                    <th className="border border-yellow-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Upcoming Task</th>
                    <th className="border border-yellow-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Due Date</th>
                    <th className="border border-yellow-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Notes</th>
                    <th className="border border-yellow-200 px-3 py-2 text-center text-sm font-medium text-gray-700 w-12">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {meetingData.upcomingTasks.map((task) => (
                    <tr key={task.id}>
                      <td className="border border-yellow-200 px-3 py-2">
                        <input
                          type="text"
                          value={task.task}
                          onChange={(e) => updateUpcomingTask(task.id, 'task', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-yellow-500 rounded"
                          placeholder="Task description"
                        />
                      </td>
                      <td className="border border-yellow-200 px-3 py-2">
                        <input
                          type="date"
                          value={task.dueDate}
                          onChange={(e) => updateUpcomingTask(task.id, 'dueDate', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-yellow-500 rounded"
                        />
                      </td>
                      <td className="border border-yellow-200 px-3 py-2">
                        <input
                          type="text"
                          value={task.notes}
                          onChange={(e) => updateUpcomingTask(task.id, 'notes', e.target.value)}
                          className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-yellow-500 rounded"
                          placeholder="Notes"
                        />
                      </td>
                      <td className="border border-yellow-200 px-3 py-2 text-center">
                        <button
                          onClick={() => removeUpcomingTask(task.id)}
                          className="text-red-500 hover:text-red-700 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {meetingData.upcomingTasks.length === 0 && (
                    <tr>
                      <td colSpan={4} className="border border-yellow-200 px-3 py-4 text-center text-gray-500">
                        No upcoming tasks yet. Click "Add Task" to get started.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Section 4: Roadblocks or Challenges */}
        <div className="bg-white rounded-xl shadow-lg border border-red-200 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Section 4: Roadblocks or Challenges</h2>
            <button
              onClick={addChallenge}
              className="flex items-center gap-2 px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Challenge
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-red-200">
              <thead>
                <tr className="bg-red-50">
                  <th className="border border-red-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Challenges</th>
                  <th className="border border-red-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Suggested Solutions</th>
                  <th className="border border-red-200 px-3 py-2 text-center text-sm font-medium text-gray-700 w-12">Actions</th>
                </tr>
              </thead>
              <tbody>
                {meetingData.challenges.map((challenge) => (
                  <tr key={challenge.id}>
                    <td className="border border-red-200 px-3 py-2">
                      <textarea
                        value={challenge.challenge}
                        onChange={(e) => updateChallenge(challenge.id, 'challenge', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-red-500 rounded resize-none"
                        placeholder="Describe the challenge"
                        rows={2}
                      />
                    </td>
                    <td className="border border-red-200 px-3 py-2">
                      <textarea
                        value={challenge.suggestedSolution}
                        onChange={(e) => updateChallenge(challenge.id, 'suggestedSolution', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-red-500 rounded resize-none"
                        placeholder="Suggested solution"
                        rows={2}
                      />
                    </td>
                    <td className="border border-red-200 px-3 py-2 text-center">
                      <button
                        onClick={() => removeChallenge(challenge.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {meetingData.challenges.length === 0 && (
                  <tr>
                    <td colSpan={3} className="border border-red-200 px-3 py-4 text-center text-gray-500">
                      No challenges yet. Click "Add Challenge" to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 5: Action Items & Follow-Ups */}
        <div className="bg-white rounded-xl shadow-lg border border-indigo-200 p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Section 5: Action Items & Follow-Ups</h2>
            <button
              onClick={addActionItem}
              className="flex items-center gap-2 px-3 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Action Item
            </button>
          </div>
          <p className="text-gray-600 mb-4">Track commitments and due dates from this meeting.</p>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-indigo-200">
              <thead>
                <tr className="bg-indigo-50">
                  <th className="border border-indigo-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Action Item</th>
                  <th className="border border-indigo-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Owner</th>
                  <th className="border border-indigo-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Due Date</th>
                  <th className="border border-indigo-200 px-3 py-2 text-left text-sm font-medium text-gray-700">Status</th>
                  <th className="border border-indigo-200 px-3 py-2 text-center text-sm font-medium text-gray-700 w-12">Actions</th>
                </tr>
              </thead>
              <tbody>
                {meetingData.actionItems.map((item) => (
                  <tr key={item.id}>
                    <td className="border border-indigo-200 px-3 py-2">
                      <input
                        type="text"
                        value={item.item}
                        onChange={(e) => updateActionItem(item.id, 'item', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-indigo-500 rounded"
                        placeholder="Action item description"
                      />
                    </td>
                    <td className="border border-indigo-200 px-3 py-2">
                      <input
                        type="text"
                        value={item.owner}
                        onChange={(e) => updateActionItem(item.id, 'owner', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-indigo-500 rounded"
                        placeholder="Owner name"
                      />
                    </td>
                    <td className="border border-indigo-200 px-3 py-2">
                      <input
                        type="date"
                        value={item.dueDate}
                        onChange={(e) => updateActionItem(item.id, 'dueDate', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-indigo-500 rounded"
                      />
                    </td>
                    <td className="border border-indigo-200 px-3 py-2">
                      <select
                        value={item.status}
                        onChange={(e) => updateActionItem(item.id, 'status', e.target.value)}
                        className="w-full px-2 py-1 border-0 focus:ring-1 focus:ring-indigo-500 rounded"
                      >
                        <option value="Not Started">Not Started</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Blocked">Blocked</option>
                      </select>
                    </td>
                    <td className="border border-indigo-200 px-3 py-2 text-center">
                      <button
                        onClick={() => removeActionItem(item.id)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {meetingData.actionItems.length === 0 && (
                  <tr>
                    <td colSpan={5} className="border border-indigo-200 px-3 py-4 text-center text-gray-500">
                      No action items yet. Click "Add Action Item" to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer Tip */}
        <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200 p-4 text-center">
          <p className="text-cyan-800 flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-600" />
            📌 Tip: Your data is automatically saved as you type. Export to markdown to share with your manager.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MeetingTemplate;